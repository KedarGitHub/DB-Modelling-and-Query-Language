from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
import pkg_resources

templateFolder = pkg_resources.resource_filename(__name__, 'templates')

app = Flask(__name__, template_folder=templateFolder)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:Window$98@localhost/Library'
db = SQLAlchemy(app)

@app.route('/')
def index():
    result = db.session.execute('SELECT * FROM author order by author_id')
    return render_template("author.html", result=result)


@app.route('/book')
def book():
    result = db.session.execute('SELECT * FROM book order by book_id')
    return render_template("book.html", result=result)


@app.route('/available_books')
def test():
    result = db.session.execute('''select b.book_title, count(c.book_id) as books from book b, book_copy c where b.book_id=c.book_id 
and available='Available' group by b.book_title order by b.book_title''')
    return render_template("available_books.html", result=result)


# @app.route('/active_customers')
# def active_customer():
#     result = db.session.execute('''SELECT
#   b.book_title AS "Book Title",
#   a.name AS "Author Name",
#   cat.category_name AS "Category Name",
#   CONCAT(cust.customer_first_name, ' ', cust.customer_last_name) AS "Customer Name",
#   ch.issue_date AS "Issue Date",
#   ch.due_date AS "Due Date",
#   ch.actual_return_date AS "Actual Return Date",
#   ch.fine AS "Fine"
# FROM
#   book_copy bc
#   INNER JOIN book b ON bc.book_id = b.book_id
#   INNER JOIN book_author_relation ba ON b.book_id = ba.book_id
#   INNER JOIN author a ON a.author_id = ba.author_id
#   INNER JOIN book_category_relation bcat ON b.book_id = bcat.book_id
#   INNER JOIN category cat ON bcat.category_id = cat.category_id
#   INNER JOIN checkout ch ON bc.unique_book_id = ch.unique_book_id
#   INNER JOIN customer cust ON ch.customer_id_card_number = cust.customer_id_card_number
# WHERE
#   cust.customer_status = 'Active';''')
#     return render_template("active_customers.html", result=result)